"""
MMS-TTS service — native Tedim + Burmese narration on aivirtual.church
=======================================================================
Replaces the fil-PH edge-tts workaround for Tedim and gives you a fully
local Burmese voice (no Microsoft dependency).

Models (auto-downloaded once to ~/.cache/huggingface):
  facebook/mms-tts-ctd  — Tedim Chin   (~145 MB)
  facebook/mms-tts-mya  — Burmese      (~145 MB)
VITS, ~36M params each -> faster-than-realtime on the 4-OCPU Ampere.
License: CC-BY-NC-4.0 (fine for ministry use, not for commercial resale).

pip install transformers torch scipy myanmar-tools
Run CPU-only: works out of the box, torch will use ARM NEON.

Where the LLMs fit in this pipeline:
  church-multilingual model = text normalizer BEFORE this service
  (spell out numbers, expand abbreviations, transliterate English
  loanwords) — VITS reads exactly what you give it, it cannot
  normalize "Jn 3:16" or "2026" by itself.
"""

import asyncio
import io

import scipy.io.wavfile
import torch
from fastapi import APIRouter, HTTPException
from fastapi.responses import Response
from myanmartools import ZawgyiDetector
from pydantic import BaseModel
from transformers import AutoTokenizer, VitsModel

router = APIRouter(prefix="/tts", tags=["mms-tts"])

MODELS = {
    "tedim": "facebook/mms-tts-ctd",
    "burmese": "facebook/mms-tts-mya",
}

_cache: dict[str, tuple] = {}
_lock = asyncio.Semaphore(1)
_zawgyi = ZawgyiDetector()
torch.set_num_threads(3)  # leave one core for Gunicorn/MySQL


def _load(lang: str):
    if lang not in _cache:
        name = MODELS[lang]
        _cache[lang] = (
            VitsModel.from_pretrained(name),
            AutoTokenizer.from_pretrained(name),
        )
    return _cache[lang]


class TTSIn(BaseModel):
    text: str
    lang: str  # "tedim" | "burmese"
    seed: int = 42  # VITS duration predictor is stochastic; pin for
                    # reproducible narration across pipeline re-runs


@router.post("/speak")
async def speak(body: TTSIn) -> Response:
    if body.lang not in MODELS:
        raise HTTPException(400, f"lang must be one of {list(MODELS)}")

    if body.lang == "burmese" and \
            _zawgyi.get_zawgyi_probability(body.text) > 0.95:
        raise HTTPException(422, "Zawgyi rejected — Myanmar Unicode only")

    model, tok = _load(body.lang)
    inputs = tok(body.text, return_tensors="pt")

    async with _lock:
        torch.manual_seed(body.seed)
        with torch.no_grad():
            wav = model(**inputs).waveform[0].cpu().numpy()

    buf = io.BytesIO()
    scipy.io.wavfile.write(buf, rate=model.config.sampling_rate, data=wav)
    return Response(content=buf.getvalue(), media_type="audio/wav")


# --------------------------------------------------------------------------
# Celery-side replacement for narrate_tedim (drop the fil-PH workaround):
#
# @shared_task
# def narrate(segment: dict) -> dict:
#     lang = "tedim" if segment["lang"] == "zo" else "burmese"
#     # 1) normalize text via church-multilingual LLM first:
#     #    POST /tedim/generate  "Rewrite for narration, spell out
#     #    numbers and references: {text}"
#     # 2) synthesize:
#     r = requests.post("http://127.0.0.1:8000/tts/speak",
#                       json={"text": segment[f"{lang}_text"], "lang": lang},
#                       timeout=600)
#     path = f"/var/www/church/storage/audio/seg_{segment['id']}_{lang}.wav"
#     open(path, "wb").write(r.content)
#     # 3) ffmpeg -i seg.wav -codec:a libmp3lame -b:a 96k seg.mp3
#     segment[f"{lang}_audio"] = path
#     return segment
# --------------------------------------------------------------------------
