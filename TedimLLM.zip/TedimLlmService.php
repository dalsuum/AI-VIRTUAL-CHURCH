<?php

// =====================================================================
// app/Services/TedimLlmService.php
// Laravel 11 side: thin client to the FastAPI Tedim endpoints.
// Laravel orchestrates (liturgy plan, DB, Vue API); Python owns inference.
// =====================================================================

namespace App\Services;

use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;

class TedimLlmService
{
    private string $base;

    public function __construct()
    {
        $this->base = config('services.tedim_llm.url', 'http://127.0.0.1:8000');
    }

    public function translateToTedim(string $english): string
    {
        // Second cache layer in Laravel keeps Vue page loads instant
        $key = 'tedim:' . sha1($english);

        return Cache::remember($key, now()->addDays(30), function () use ($english) {
            $resp = Http::timeout(600)
                ->retry(2, 5000)
                ->post("{$this->base}/tedim/translate", [
                    'text' => $english,
                    'direction' => 'en2zo',
                ]);

            return $resp->throw()->json('text');
        });
    }

    public function generateDevotional(string $prompt, int $maxTokens = 512): string
    {
        return Http::timeout(600)
            ->post("{$this->base}/tedim/generate", [
                'prompt' => $prompt,
                'max_tokens' => $maxTokens,
            ])
            ->throw()
            ->json('text');
    }
}

// =====================================================================
// app/Jobs/LocalizeServiceToTedim.php
// Dispatched after the English worship service is assembled.
// =====================================================================

namespace App\Jobs;

use App\Models\ServiceSegment;
use App\Models\WorshipService;
use App\Services\TedimLlmService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class LocalizeServiceToTedim implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $timeout = 3600;   // full service can take a while on ARM CPU
    public int $tries = 2;

    public function __construct(public WorshipService $service) {}

    public function handle(TedimLlmService $llm): void
    {
        $this->service->segments()
            ->whereNull('tedim_text')
            ->orderBy('position')
            ->each(function (ServiceSegment $seg) use ($llm) {
                $seg->update([
                    'tedim_text' => $seg->type === 'scripture'
                        // exact verse from the local Bible corpus table
                        ? $seg->verseFromCorpus('tedim')
                        : $llm->translateToTedim($seg->english_text),
                ]);
            });

        $this->service->update(['tedim_status' => 'ready']);
        // Next stage: Python Celery picks up narration via Redis queue,
        // or dispatch your existing NarrationJob here.
    }
}

// =====================================================================
// config/services.php  — add:
//
//   'tedim_llm' => [
//       'url' => env('TEDIM_LLM_URL', 'http://127.0.0.1:8000'),
//   ],
//
// .env — add:
//
//   TEDIM_LLM_URL=http://127.0.0.1:8000
// =====================================================================
