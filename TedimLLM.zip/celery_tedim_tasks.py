"""
Celery tasks — Tedim localization stage in the worship pipeline
================================================================
Pipeline order (chain):
  build_liturgy -> generate_sermon_en -> localize_tedim -> narrate_tts
                                                        -> generate_music

Key design rule:
  SCRIPTURE never goes through the LLM. Pull verses directly from your
  local Bible corpus (github.com/dalsuum/bible) — it's exact and free.
  The LLM handles only PROSE: sermon body, prayers, announcements,
  transitions. This keeps doctrinal text deterministic and saves
  inference time on the ARM box.
"""

import hashlib

import requests
from celery import shared_task

FASTAPI_BASE = "http://127.0.0.1:8000"  # your existing FastAPI service


def _translate(text: str) -> str:
    r = requests.post(
        f"{FASTAPI_BASE}/tedim/translate",
        json={"text": text, "direction": "en2zo"},
        timeout=600,
    )
    r.raise_for_status()
    return r.json()["text"]


@shared_task(bind=True, max_retries=2, default_retry_delay=30,
             acks_late=True)
def localize_segment_tedim(self, segment: dict) -> dict:
    """
    segment = {
      "id": int, "type": "scripture"|"sermon"|"prayer"|"announcement",
      "english_text": str, "ref": str|None
    }
    Returns segment with "tedim_text" filled.
    """
    try:
        if segment["type"] == "scripture" and segment.get("ref"):
            # Exact lookup from local Tedim Bible corpus, NOT the LLM
            from app.services.bible_corpus import get_verse_tedim
            segment["tedim_text"] = get_verse_tedim(segment["ref"])
        else:
            # Translate paragraph-by-paragraph: the 3B model is far more
            # reliable on 1-3 sentence chunks than on full sermons.
            paras = [p for p in segment["english_text"].split("\n\n") if p.strip()]
            segment["tedim_text"] = "\n\n".join(_translate(p) for p in paras)
        return segment
    except requests.RequestException as exc:
        raise self.retry(exc=exc)


@shared_task
def narrate_tedim(segment: dict) -> dict:
    """
    edge-tts has NO Tedim voice. Tedim uses Latin script with fairly
    phonetic spelling, so the practical workarounds, in order of quality:
      1. fil-PH-AngeloNeural / fil-PH-BlessicaNeural  (Filipino —
         closest vowel inventory, handles 'aw', 'ng' clusters well)
      2. id-ID-ArdiNeural (Indonesian — clean open vowels)
      3. sw-KE voices (Swahili — surprisingly decent for CV syllables)
    Test all three against a native ear and pin one in config.
    """
    import asyncio

    import edge_tts

    voice = "fil-PH-BlessicaNeural"
    out_path = f"/var/www/church/storage/audio/seg_{segment['id']}_zo.mp3"

    async def run():
        tts = edge_tts.Communicate(segment["tedim_text"], voice, rate="-10%")
        await tts.save(out_path)

    asyncio.run(run())
    segment["tedim_audio"] = out_path
    return segment
