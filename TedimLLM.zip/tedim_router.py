"""
Tedim LLM service — aivirtual.church FastAPI layer
===================================================
Mount this router in your existing FastAPI app (same process that runs
your Celery producers). It wraps the local Ollama model with:
  - Redis caching (translations are deterministic-ish at temp 0.3,
    and sermon segments repeat across services)
  - Concurrency guard (the OCI ARM box can realistically run ONE
    generation at a time without starving Gunicorn/MySQL)

Routes:
  POST /tedim/translate   {"text": "...", "direction": "en2zo"|"zo2en"}
  POST /tedim/generate    {"prompt": "...", "system": "..."}  (free-form Tedim prose)
"""

import asyncio
import hashlib
import json

import httpx
import redis.asyncio as aioredis
from fastapi import APIRouter
from pydantic import BaseModel

router = APIRouter(prefix="/tedim", tags=["tedim-llm"])

OLLAMA_URL = "http://127.0.0.1:11434/api/generate"
MODEL = "tedim-zolai"
CACHE_TTL = 60 * 60 * 24 * 30  # 30 days
_redis = aioredis.from_url("redis://127.0.0.1:6379/2", decode_responses=True)
_gpu_lock = asyncio.Semaphore(1)  # one inference at a time on ARM CPU


class TranslateIn(BaseModel):
    text: str
    direction: str = "en2zo"  # en2zo | zo2en


class GenerateIn(BaseModel):
    prompt: str
    system: str | None = None
    max_tokens: int = 512


async def _ollama(prompt: str, system: str | None = None,
                  max_tokens: int = 512) -> str:
    payload = {
        "model": MODEL,
        "prompt": prompt,
        "stream": False,
        "options": {
            "temperature": 0.3,
            "top_p": 0.9,
            "num_ctx": 2048,
            "num_predict": max_tokens,
        },
    }
    if system:
        payload["system"] = system
    async with _gpu_lock:
        async with httpx.AsyncClient(timeout=600) as client:
            r = await client.post(OLLAMA_URL, json=payload)
            r.raise_for_status()
            return r.json()["response"].strip()


@router.post("/translate")
async def translate(body: TranslateIn):
    key = "tedim:tr:" + hashlib.sha1(
        f"{body.direction}|{body.text}".encode()).hexdigest()
    if cached := await _redis.get(key):
        return {"text": cached, "cached": True}

    prompt = (
        f"Translate to Tedim (Zolai): {body.text}"
        if body.direction == "en2zo"
        else f"Translate to English: {body.text}"
    )
    out = await _ollama(prompt)
    await _redis.set(key, out, ex=CACHE_TTL)
    return {"text": out, "cached": False}


@router.post("/generate")
async def generate(body: GenerateIn):
    system = body.system or (
        "You are a Tedim (Zolai) language assistant for a virtual church. "
        "Write devotional content in natural Tedim using standard Zolai "
        "orthography."
    )
    out = await _ollama(body.prompt, system=system, max_tokens=body.max_tokens)
    return {"text": out}
