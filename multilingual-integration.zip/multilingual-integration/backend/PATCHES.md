# Backend patches (hand-apply, 2 files)

The migration and `DispatchServiceJob.php` in this bundle are drop-in. Two more
files need three small edits each — shown as exact before/after so they apply
cleanly regardless of local drift.

## 1. `backend/app/Models/ServiceSession.php`

Add `language` to the fillable list:

```php
// BEFORE
protected $fillable = [
    'user_id', 'session_token', 'status', 'music_source', 'scheduled_at', 'contact_email', 'started_at', 'ended_at',
];

// AFTER
protected $fillable = [
    'user_id', 'session_token', 'status', 'music_source', 'language', 'scheduled_at', 'contact_email', 'started_at', 'ended_at',
];
```

## 2. `backend/app/Http/Controllers/ServiceController.php`

### 2a. `intake()` — accept the language with the intake payload

In the `$request->validate([...])` block, add one rule:

```php
$data = $request->validate([
    'mood'          => ['required', 'string', 'max:100'],
    // Service language ('en' | 'my' Burmese | 'td' Tedim Chin), chosen on the
    // intake form's language tabs. Locked per session like music_source; the
    // worker keys the LLM output language, Bible translation (BSB / Judson
    // 1835 / Lai Siangtho 1932), hymn library, and TTS voice off it.
    'language'      => ['nullable', 'string', 'in:en,my,td'],
    'custom_mood'   => ['nullable', 'string', 'max:50', 'regex:/^[A-Za-z]+$/'],
    'prayer_text'   => ['nullable', 'string', 'max:5000'],
    'scheduled_at'  => ['nullable', 'date', 'after:now'],
    'contact_email' => ['nullable', 'email', 'max:255'],
]);
```

### 2b. `intake()` — persist it on the session

Immediately after the validation block (before any dispatch/scheduling logic):

```php
// Lock the service language now, alongside the already-locked music source.
$session->update(['language' => $data['language'] ?? 'en']);
```

That's all: `DispatchServiceJob` (replaced by this bundle) reads
`$session->language` into the Redis payload, and the workers take it from there.

## Note on the crisis intercept

`CrisisInterceptService` scans `prayer_text` with (presumably English) keyword
rules. A Burmese worshipper may write their prayer in Burmese, which those rules
won't match. This bundle does not change the intercept — but you should extend
its keyword list with Burmese crisis terms before promoting the Myanmar tab to
production, or route the scan through your existing classifier with a
language-aware prompt. Flagging it here so it isn't silently lost.
